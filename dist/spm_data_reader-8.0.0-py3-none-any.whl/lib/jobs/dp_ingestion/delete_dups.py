"""
This script manages Hudi table operations such as loading,
backing up, deleting records, and ensuring data integrity
in partitioned S3-based Hudi tables.
"""

import os
import optparse
from pyspark.conf import SparkConf
from pyspark.sql import SparkSession
from lib.common.logger import Logger
from lib.common.constants import HudiConstants
import sys

logger = Logger("Hudi Data Manager")


class HudiDataManager:
    """
    Manages Hudi table operations including loading data,
    backing up records, deleting records, and ensuring data
    integrity in a partitioned table stored in S3.

    Attributes:
        config (dict): Configuration dictionary for Hudi.
        spark (SparkSession): The Spark session used for Hudi.
    """

    def __init__(self, conf):
        """
        Initialize the HudiDataManager with the provided config.

        Args:
            config (dict): Configuration dictionary for Hudi.
        """
        self.config = conf
        self.spark = self._get_spark_session()

    def _get_spark_session(self):
        """
        Initialize and return a Spark session configured 
        for Hudi operations.

        Returns:
            SparkSession: The configured Spark session.
        """
        logger.info("Initializing Spark session.")
        conf = SparkConf().set("spark.executor.instances", "1") \
                          .set("spark.dynamicAllocation.minExecutors", "1") \
                          .set("spark.dynamicAllocation.maxExecutors",
                               self.config['max_executors']) \
                          .set("spark.sql.legacy.timeParserPolicy",
                               "LEGACY") \
                          .set("spark.sql.parquet.datetimeRebaseModeInRead",
                               "LEGACY") \
                          .set("spark.sql.avro.datetimeRebaseModeInWrite", 
                               "LEGACY") \
                          .set("spark.sql.parquet.writeLegacyFormat", 
                               "true")

        app_name = f"{self.config['schema']}-" \
                   f"{self.config['table_name']}-CDC"
        spark = SparkSession.builder.enableHiveSupport() \
                            .appName(app_name) \
                            .config(conf=conf) \
                            .getOrCreate()

        spark.sparkContext.setLogLevel("ERROR")
        logger.info("Spark session initialized.")
        return spark

    def _backup(self, df):
        """
        Backup records matching the deletion criteria.

        Args:
            df (DataFrame): DataFrame containing records to backup.
        """
        backup_path = (f"s3://{self.config['bucket']}/raw-consolidated/"
                       f"{self.config['schema'].upper()}/"
                       f"{self.config['table_name'].upper()}_PART_BACKUP/")
        logger.info(f"Backing up data to {backup_path}.")
        df.write.format("parquet").mode("overwrite").save(backup_path)
        logger.info(f"Backup completed at {backup_path}.")

    def _get_duplicates(self):
        """
        Identify duplicate records based on primary keys.

        Returns:
            DataFrame: DataFrame containing duplicate records.
        """
        target_table = (f"{HudiConstants.glue_db_prefix.value.lower()}"
                        f"{self.config['schema'].lower()}."
                        f"{self.config['table_name'].lower()}")
        query = (f"SELECT * FROM {target_table} WHERE "
                 f"(PDKCOO,PDDOCO,PDDCTO,PDSFXO,PDLNID) IN "
                 f"(SELECT PDKCOO, PDDOCO, PDDCTO, PDSFXO, PDLNID "
                 f"FROM {target_table} GROUP BY PDKCOO, PDDOCO, "
                 f"PDDCTO, PDSFXO, PDLNID HAVING COUNT(*) > 1) "
                 f"AND _hoodie_partition_path='2024'")
        logger.info(f"Identifying duplicates with query:\n{query}")
        return self.spark.sql(query)

    def _delete(self, df):
        """
        Delete duplicate records from the Hudi table.

        Args:
            df (DataFrame): DataFrame containing duplicates.
        """
        logger.info(f"Deleting {df.count()} duplicate records.")
        df.write.format(HudiConstants.HUDI_FORMAT.value) \
            .option(HudiConstants.PRECOMBINE_FIELD_OPT_KEY.value, 
                    self.config["sort_key"]) \
            .option(HudiConstants.RECORDKEY_FIELD_OPT_KEY.value, 
                    self.config["primary_key"]) \
            .option(HudiConstants.TABLE_NAME.value, 
                    self.config['table_name']) \
            .option(HudiConstants.OPERATION_OPT_KEY.value, 
                    HudiConstants.DELETE_OPERATION_OPT_VAL.value) \
            .option(HudiConstants.UPSERT_PARALLELISM.value, 
                    self.config['upsert_parallelism']) \
            .option(HudiConstants.PARTITIONPATH_FIELD_OPT_KEY.value, 
                    "partitionpath") \
            .option(HudiConstants.HIVE_SYNC_ENABLED_OPT_KEY.value, 
                    HudiConstants.bolHiveSync.value) \
            .option(HudiConstants.HIVE_TABLE_OPT_KEY.value, 
                    self.config['table_name']) \
            .option(HudiConstants.HIVE_DATABASE_OPT_KEY.value, 
                    f"{HudiConstants.glue_db_prefix.value.lower()}"
                    f"{self.config['schema'].lower()}") \
            .mode("Append").save(self.config['target'])
        logger.info("Records deleted successfully.")

    def _verify(self):
        """
        Verify the deletion process by checking record count.
        """
        target_table = (f"{HudiConstants.glue_db_prefix.value.lower()}"
                        f"{self.config['schema'].lower()}."
                        f"{self.config['table_name'].lower()}")
        target_df = self.spark.sql(f"SELECT COUNT(*) FROM {target_table}")
        record_count = target_df.collect()[0][0]
        logger.info(f"Post-deletion record count: {record_count}")

    def manage(self):
        """
        Manage the Hudi data process, deleting duplicates 
        and ensuring integrity.
        """
        logger.info("Starting Hudi data management process.")
        df = self._get_duplicates()
        if df.count() > 0:
            # df.show()
            # sys.exit(0)
            self._backup(df)
            self._delete(df)
            self._verify()
        else:
            logger.info("No duplicates found for deletion.")
        logger.info("Hudi data management process completed.")


def parse_arguments():
    """
    Parse command line arguments using optparse.

    Returns:
        dict: Configuration dictionary for the app.
    """
    parser = optparse.OptionParser()
    parser.add_option("--sbucket", type=str, 
                      default="baxaws-prd-enterpriseanalytics-edh-jdeeu-inbound")
    parser.add_option("--sregion", type=str, default="eu-central-1")
    parser.add_option("-b", "--bucket", type=str, 
                      default="baxaws-prd-enterpriseanalytics-edh-jde-inbound")
    parser.add_option("-s", "--schema", type=str, default="EUDTA")
    parser.add_option("-t", "--table", type=str, default="f4311")
    parser.add_option("--primary_key", type=str, 
                      default="PDKCOO,PDDOCO,PDDCTO,PDSFXO,PDLNID")
    parser.add_option("--sort_key", type=str, default="change_seq")
    parser.add_option("-r", "--max_executors", type=str, default="5")
    parser.add_option("-p", "--bulk_insert_parallelism", type=int, default=6)
    parser.add_option("-u", "--upsert_parallelism", type=int, default=6)

    (options, args) = parser.parse_args()
    logger.info(f"Command-line arguments: {args}")

    config = {
        "sbucket": options.sbucket,
        "sregion": options.sregion,
        "bucket": options.bucket,
        "schema": options.schema,
        "table_name": options.table,
        "primary_key": options.primary_key,
        "sort_key": options.sort_key,
        "max_executors": options.max_executors,
        "bulk_insert_parallelism": options.bulk_insert_parallelism,
        "upsert_parallelism": options.upsert_parallelism,
        "target": os.path.join("s3://", options.bucket, 
                               "raw-consolidated", 
                               options.schema, 
                               options.table + '_PART')
    }
    return config


if __name__ == '__main__':
    config = parse_arguments()
    manager = HudiDataManager(config)
    manager.manage()
